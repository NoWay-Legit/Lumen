MIT License

Copyright (c) 2025

Permission is hereby granted, free of charge, to any person obtaining a copy
...

# 🌙 Lumen Discord Theme

A modern dark Discord theme inspired by Midnight, built with SCSS.

## 📦 Installation
1. Download **Lumen.theme.css** from `dist/`.
2. Place it into your BetterDiscord/Vencord themes folder.
3. Enable it in your client.

This file automatically imports the latest `lumen.css` from GitHub.

## ⚙️ Development
```bash
npm install
npm run build
```

- `src/lumen.css` → Source theme (without --variables)
- `dist/Lumen.theme.css` → Theme file with @import (for BetterDiscord/Vencord)
